#ifndef TOWERPOSITION_H
#define TOWERPOSITION_H
#include<QPoint>
#include<QImage>
#include<QPainter>


class towerposition
{
public:
    towerposition();
    void setposition(QPointF pos);
    void sethastower();
    void setnotower(){
        _hastower=false;
    }
    bool hastower();
    bool containpoint(QPoint &pos);
    void show(QPainter * painter);
    QPointF getpos() const{ return this->_pos;}
private:
    QPointF _pos;
    bool _hastower;
    QImage _pic;
};

#endif // TOWERPOSITION_H
