#include "mainwindow.h"
#include "ui_mainwindow.h"
int MainWindow::count=0;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    if(count==0){
        music=new QMediaPlayer;
        music->setMedia(QUrl("qrc:/yinyue/C:/Users/Administrator/Desktop/cs/tanchishe.mp3"));
        music->setVolume(50);
        music->play();
    }
    count++;
}

MainWindow::~MainWindow()
{
    delete ui;

}

void MainWindow::on_pushButton_clicked()
{
    first *ui0=new first;
    this->hide();
    ui0->show();
    music=new QMediaPlayer;
    music->setMedia(QUrl("qrc:/yinyue/C:/Users/Administrator/Desktop/cs/ui1.wav"));
    music->setVolume(50);
    music->play();

}


