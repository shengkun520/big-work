#include "monster.h"

monster::monster()
{
    _pos_x=16.3;
    _pos_y=3;
    _state=true;

}

void monster::setpic(QString name){
    QImage all;
    all.load(":/tu/C:/Users/Administrator/Desktop/cs/1.jpg");
    if(name=="huo"){
        _pic=all.copy(QRect(10,7,1*50,1*50));
        _life_value=currentlife=50;
    }
    if(name=="shui"){
        _pic=all.copy(QRect(83,7,1*50,1*50));
        _life_value=currentlife=100;
    }
    if(name=="dian"){
        _pic=all.copy(QRect(1*50,1*50,1*50,1*50));
        _life_value=currentlife=200;
    }
    if(name=="tu"){
        _pic=all.copy(QRect(10,95,1*50,1*50));
        _life_value=currentlife=250;
    }
    if(name=="feng"){
        _pic=all.copy(QRect(89,97,1*50,1*50));
        _life_value=currentlife=300;
    }
}

void monster::show(QPainter *painter){
    painter->drawImage(_pos_x*50,_pos_y*50,_pic);

    double Health_Bar_Width=50;
    painter->save();
    QPointF healthBarPoint(_pos_x*50,_pos_y*50-5);
    painter->setPen(Qt::NoPen);
    painter->setBrush(Qt::red);
    QRectF healthBarBackRect(healthBarPoint,QSizeF(Health_Bar_Width,5));
    painter->drawRect(healthBarBackRect);
    painter->setBrush(Qt::green);
    QRectF healthBarRect(healthBarPoint,QSizeF(currentlife/_life_value*Health_Bar_Width,5));
    painter->drawRect(healthBarRect);//����Ѫ��
    painter->restore();
}

void monster::move(int direction){
    if(direction==1)
        _pos_y-=0.01;
    if(direction==2)
        _pos_y+=0.01;
    if(direction==3)
        _pos_x-=0.01;
    if(direction==4)
        _pos_x+=0.01;
}

void monster::getattacked(){
    if(_attacktower.getname()=="lv"||_attacktower.getname()=="bai"){
        currentlife-=4;
    }if(_attacktower.getname()=="lv2"||_attacktower.getname()=="hong"){
        currentlife-=7;
    }if(_attacktower.getname()=="lv3"||_attacktower.getname()=="hong2"){
        currentlife-=9;
    }
}

void monster::setstate(){
    if(currentlife>0){
        _state=true;
    }else{
        _state=false;
    }
}

bool monster::living(){
    return _state;
}


