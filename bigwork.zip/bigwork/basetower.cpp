#include "basetower.h"

basetower::basetower()
{

}

void basetower::setpic(QString name){
    _name=name;
    if(name=="lv"){
        _pic.load(":/tu/C:/Users/Administrator/Desktop/cs/7.jpg");
        _pos_x=4,_pos_y=0;
    }if(name=="bai"){
        _pic.load(":/tu/C:/Users/Administrator/Desktop/cs/4.jpg");
        _pos_x=5,_pos_y=0;
    }if(name=="hong"){
        _pic.load(":/tu/C:/Users/Administrator/Desktop/cs/15.jpg");
        _pos_x=6,_pos_y=0;
    }
}

void basetower::show(QPainter *painter){
    painter->drawImage(_pos_x*50,_pos_y*50,_pic);
}

bool basetower::containpoint(QPoint &pos){
    bool x=_pos_x*50<=pos.x()&&pos.x()<=(_pos_x+1)*50;
    bool y=_pos_y*50<=pos.y()&&pos.y()<=(_pos_y+1)*50;
    return x&&y;
}
