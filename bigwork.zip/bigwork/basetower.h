#ifndef BASETOWER_H
#define BASETOWER_H
#include<QImage>
#include<string>
#include<QPainter>

class basetower
{
public:
    basetower();
    void setpic(QString name);
    void show(QPainter *painter);
    bool containpoint(QPoint &pos);
    QString getname(){
        return _name;
    }
private:
    QImage _pic;
    double _pos_x;
    double _pos_y;
    QString _name;
};

#endif // BASETOWER_H
