#ifndef BULLET_H
#define BULLET_H
#include<QImage>
#include<QPoint>

#include<QPropertyAnimation>
#include<QPainter>


class bullet
{


public:
    bullet();
    bullet(QPointF startpos,QPointF endpos);

    void show(QPainter *painter);
    int gets(){ return _has_no;}
    void sets(){
        _has_no=1;
    }
    void setno(){
        _has_no=0;
    }



private:
    QImage _pic;
    QPointF _startpos;
    QPointF _endpos;
    QPointF _currentpos;
    int _has_no;

};

#endif // BULLET_H
