#ifndef FIRST_H
#define FIRST_H

#include <QDialog>
#include"mainwindow.h"
#include<QTimer>
#include"monster.h"
#include<QTime>
#include<QPainter>
#include"towerposition.h"
#include"tower.h"
#include<QMouseEvent>
#include"basetower.h"
#include<QMediaPlayer>

namespace Ui {
class first;
}

class first : public QDialog
{
    Q_OBJECT

public:
    explicit first(QWidget *parent = 0);
    ~first();
    void init();
    void paintEvent(QPaintEvent *e);
    void mousePressEvent(QMouseEvent *e);
    bool canbyplant();
    void drawmygold(QPainter *painter);
    QMediaPlayer *music;
    QMediaPlayer *music1;




private slots:

    void move();
    void attack();
    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::first *ui;
    QTimer *_move_timer;
    QTimer *_attack_timer;
    monster enemy[5][5];
    QTime basetime;
    QList<towerposition> towerplist;
    tower tow[11];
    basetower basetow[3];
    static int count;
    static int select;
    int location1;
    int location2;
    int _mygold;
    static int plantcost;

};

#endif // FIRST_H
