#include "towerposition.h"

towerposition::towerposition()
{
    _hastower=false;

    _pic.load(":/_pic/C:/Users/Administrator/Desktop/cs/21.jpg");
}
void towerposition::setposition(QPointF pos){
    _pos=pos;
}

void towerposition::sethastower(){
    _hastower=true;
}

bool towerposition::hastower(){
    return _hastower;
}

bool towerposition::containpoint(QPoint &pos){
    bool x=_pos.x()*50<=pos.x()&&pos.x()<=(_pos.x()+1)*50;
    bool y=_pos.y()*50<=pos.y()&&pos.y()<=(_pos.y()+1)*50;
    return x&&y;
}

void towerposition::show(QPainter *painter){
    painter->drawImage(_pos.x()*50,_pos.y()*50,_pic);
}
