#ifndef TOWER_H
#define TOWER_H
#include<QImage>
#include<QPainter>
#include<QPoint>
#include<string>
#include"bullet.h"






class tower
{
public:
    tower();
    void show(QPainter *painter);
    void setposition(QPointF  point);
    QPointF getpos(){ return this->_pos;}
    bool hasenemy();
    int getr(){ return _attack_r;}
    void setpic(QString name);
    QString getname(){ return this->_name;}
    bullet getweapon1(){
        return weapon[0];
    }bullet getweapon2(){
        return weapon[1];
    }
    void setweapon1(bullet gun){
        weapon[0]=gun;
    }void setweapon2(bullet gun){
        weapon[1]=gun;
    }
    bool containpoint(QPoint pos);



private:
    QString _name;
    QImage _pic;
    int _attack_r;
    QPointF _pos;
    bool _hasenemy;
    bullet weapon[2];

};

#endif // TOWER_H
