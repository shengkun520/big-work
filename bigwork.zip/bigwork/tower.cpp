#include "tower.h"

tower::tower()
{

    _attack_r=6;
    _hasenemy=false;
}

void tower::show(QPainter *painter){
    painter->save();
    painter->setPen(Qt::white);
    painter->drawEllipse((_pos.x()-_attack_r/2.45)*50,(_pos.y()-_attack_r/2.45)*50,_attack_r*50,_attack_r*50);

    painter->drawImage(_pos.x()*50,_pos.y()*50,_pic);
    painter->restore();
}

void tower::setposition(QPointF point){
    _pos=point;
}

bool tower::hasenemy(){
    return _hasenemy;
}

void tower::setpic(QString name){
    _name=name;
    if(name=="lv"){
        _pic.load(":/tu/C:/Users/Administrator/Desktop/cs/7.jpg");
    }if(name=="bai"){
        _pic.load(":/tu/C:/Users/Administrator/Desktop/cs/4.jpg");
    }if(name=="hong"){
        _pic.load(":/tu/C:/Users/Administrator/Desktop/cs/15.jpg");
    }if(name=="lv2"){
        _pic.load(":/tu/C:/Users/Administrator/Desktop/cs/13.jpg");
    }if(name=="lv3"){
        _pic.load(":/tu/C:/Users/Administrator/Desktop/cs/14.jpg");
    }if(name=="hong2"){
        _pic.load(":/tu/C:/Users/Administrator/Desktop/cs/16.jpg");
    }
}

bool tower::containpoint(QPoint pos){
    bool x=_pos.x()*50<=pos.x()&&pos.x()<=(_pos.x()+1)*50;
    bool y=_pos.y()*50<=pos.y()&&pos.y()<=(_pos.y()+1)*50;
    return x&&y;
}

