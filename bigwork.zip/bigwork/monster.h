#ifndef MONSTER_H
#define MONSTER_H
#include<string>
#include<QImage>
#include<QPainter>
#include<QTimer>
#include<QObject>
#include"tower.h"
#include<QMediaPlayer>


class monster
{

public:
    monster();
    void setpic(QString name);
    void show(QPainter *painter);
    void move(int direction);
    double getX(){ return this->_pos_x;}
    double getY(){ return this->_pos_y;}
    void getattacked();
    void setstate();
    bool living();
    void settower(tower attacktower){
        _attacktower=attacktower;
    }


private:
    QImage _pic;
    double _pos_x;
    double _pos_y;
    double _life_value;
    double currentlife;
    bool _state;
    tower _attacktower;

};

#endif // MONSTER_H
