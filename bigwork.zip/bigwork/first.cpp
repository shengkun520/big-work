#include "first.h"
#include "ui_first.h"
int first::count=0;
int first::select=0;
int first::plantcost=300;


first::first(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::first)
{
    ui->setupUi(this);
    init();
    setMouseTracking(true);
    ui->pushButton_2->hide();
    ui->pushButton_3->hide();
}

first::~first()
{
    delete ui;
    delete _move_timer;
    delete _attack_timer;

}



void first::init(){
    _mygold=600;

    for(int i=0;i<5;i++){
        enemy[0][i].setpic("huo");
        enemy[1][i].setpic("shui");
        enemy[3][i].setpic("dian");
    }enemy[2][0].setpic("huo");
    enemy[2][1].setpic("shui");
    for(int i=2;i<5;i++){
        enemy[2][i].setpic("dian");
    }enemy[4][0].setpic("tu");
    enemy[4][1].setpic("tu");
    enemy[4][2].setpic("dian");
    enemy[4][3].setpic("feng");
    enemy[4][4].setpic("feng");

    towerposition towerp[11];
    for(int i=0;i<3;i++){
        towerp[i].setposition(QPointF(11.4-i,3.3));

    }
    for(int i=0;i<2;i++){
        towerp[i+7].setposition(QPointF(12.8-i*4.6,6.2));
        towerp[i+9].setposition(QPointF(1.4,2.6+i));
    }
    for(int i=0;i<4;i++){
        towerp[i+3].setposition(QPointF(6.9-i,3.8));
    }
    for(int i=0;i<11;i++){
        towerplist.push_back(towerp[i]);
    }

    basetow[0].setpic("lv");
    basetow[1].setpic("bai");
    basetow[2].setpic("hong");



    _move_timer=new QTimer;
    connect(_move_timer,SIGNAL(timeout()),this,SLOT(move()));
    _move_timer->start(0);
    _move_timer->setInterval(10);


    _attack_timer=new QTimer;
    connect(_attack_timer,SIGNAL(timeout()),this,SLOT(attack()));
    _attack_timer->start(0);
    _attack_timer->setInterval(200);

    this->basetime=this->basetime.currentTime();
}

void first::paintEvent(QPaintEvent *e){
    QPainter *pa;
    pa=new QPainter();
    pa->begin(this);
    for(int i=0;i<5;i++){
        for(int j=0;j<5;j++){
            if(enemy[i][j].living()){
                enemy[i][j].show(pa);
            }
        }
    }
    for(int i=0;i<towerplist.size();i++){
        towerplist[i].show(pa);
    }
    for(int i=0;i<count;i++){
        tow[i].show(pa);
        if(tow[i].getweapon1().gets()==1){
            tow[i].getweapon1().show(pa);
        }else{
            tow[i].getweapon2().show(pa);
        }
    }


    if(select==1){
        for(int i=0;i<3;i++){
            basetow[i].show(pa);
        }
    }

    drawmygold(pa);
    pa->end();
    delete pa;
}

void first::move(){
    QTime currtime=QTime::currentTime();
    int t=this->basetime.msecsTo(currtime);
    for(int i=0;i<5;i++){
        for(int j=0;j<5;j++){
            if(t/1000.0>=i*25+2*j+5){
            int swap=0;
            if(enemy[i][j].getX()>12.8&&enemy[i][j].getY()==3){
                enemy[i][j].move(3);
                swap=1;
            }if(swap==0){
                int swap1=0;
                if(enemy[i][j].getX()>=12.6&&enemy[i][j].getX()<=12.8&&enemy[i][j].getY()<5&&(enemy[i][j].getY()-3)>=0.0){
                    enemy[i][j].move(2);
                    swap1=1;
                }if(swap1==0){
                    int swap2=0;
                    if(enemy[i][j].getY()>=5&&enemy[i][j].getY()<=5.2&&enemy[i][j].getX()>8.2&&enemy[i][j].getX()<=12.8){
                        enemy[i][j].move(3);
                        swap2=1;
                    }if(swap2==0){
                        int swap3=0;
                        if(enemy[i][j].getX()<=8.2&&enemy[i][j].getX()>=8.0&&enemy[i][j].getY()>2.6&&enemy[i][j].getY()<=5.2){
                            enemy[i][j].move(1);
                            swap3=1;
                        }if(swap3==0){
                            int swap4=0;
                            if(enemy[i][j].getY()>=2.4&&enemy[i][j].getY()<=2.6&&enemy[i][j].getX()>2.8&&enemy[i][j].getX()<=8.2){
                                enemy[i][j].move(3);
                                swap4=1;
                            }if(swap4==0){
                                int swap5=0;
                                if(enemy[i][j].getX()>=2.6&&enemy[i][j].getX()<=2.8&&enemy[i][j].getY()<5.2&&enemy[i][j].getY()>=2.4){
                                    enemy[i][j].move(2);
                                    swap5=1;
                                }if(swap5==0){
                                    if(enemy[i][j].getY()<=5.4&&enemy[i][j].getY()>=5.2&&enemy[i][j].getX()<=3){
                                        enemy[i][j].move(3);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            }
        }
    }this->repaint();
}

void first::mousePressEvent(QMouseEvent *e){

    QPoint pos=e->pos();
    for(int i=0;i<11;i++){
        if(towerplist[i].containpoint(pos)&&!towerplist[i].hastower()&&canbyplant()){
            if(count<11){
                tow[count].setposition(towerplist[i].getpos());
                location1=i;
                select=1;
                update();
                break;
            }
        }
    }for(int i=0;i<3;i++){
        if(basetow[i].containpoint(pos)){
            tow[count].setpic(basetow[i].getname());
            towerplist[location1].sethastower();
            _mygold-=plantcost;
            count++;
            select=0;
            update();
            break;
        }
    }for(int i=0;i<count;i++){
        if(tow[i].containpoint(pos)){
            location2=i;
            ui->pushButton_2->show();
            ui->pushButton_3->show();
            update();
            for(int j=0;j<11;j++){
                if(towerplist[j].containpoint(pos)){
                    location1=j;
                }
            }
            break;
        }
    }
}

void first::attack(){
    QTime currtime=QTime::currentTime();
    int t=this->basetime.msecsTo(currtime);
    for(int i=0;i<count;i++){
        for(int j=0;j<5;j++){
            int sum=0;
            for(int k=0;k<5;k++){
                if(t>=j*25+k*2+5){
                    if((enemy[j][k].getX()-(tow[i].getpos().x()+0.5))*(enemy[j][k].getX()-(tow[i].getpos().x()+0.5))+(enemy[j][k].getY()-(tow[i].getpos().y()+0.5))*(enemy[j][k].getY()-(tow[i].getpos().y()+0.5))<=tow[i].getr()/2*tow[i].getr()/2&&enemy[j][k].living()){
                        enemy[j][k].settower(tow[i]);
                        bullet gun(tow[i].getpos(),QPointF(enemy[j][k].getX(),enemy[j][k].getY()));
                        for(int l=0;l<2;l++){
                            if(tow[i].getweapon1().gets()==0){
                                tow[i].setweapon1(gun);
                                tow[i].getweapon1().sets();
                                tow[i].getweapon2().setno();
                                break;
                            }else{
                                tow[i].setweapon2(gun);
                                tow[i].getweapon1().setno();
                                tow[i].getweapon2().sets();
                                break;
                            }
                        }

                        enemy[j][k].getattacked();
                        enemy[j][k].setstate();
                        if(!enemy[j][k].living()){
                            _mygold+=50;
                        }
                        sum=1;
                        break;
                    }
                }
            }if(sum==1){
                break;
            }
        }
    }repaint();
}









void first::on_pushButton_2_clicked()
{
    music=new QMediaPlayer;
    music->setMedia(QUrl("qrc:/yinyue/C:/Users/Administrator/Desktop/cs/ui1.wav"));
    music->setVolume(50);
    music->play();
    ui->pushButton_2->hide();
    ui->pushButton_3->hide();
    for(int i=location2;i<count-1;i++){
        tow[i]=tow[i+1];
    }
    count--;
    _mygold+=150;
    towerplist[location1].setnotower();
    repaint();
}

void first::on_pushButton_3_clicked()
{
    music=new QMediaPlayer;
    music->setMedia(QUrl("qrc:/yinyue/C:/Users/Administrator/Desktop/cs/ui1.wav"));
    music->setVolume(50);
    music->play();
    ui->pushButton_2->hide();
    ui->pushButton_3->hide();
    for(int i=0;i<1;i++){
    if(tow[location2].getname()=="lv"){
        if(canbyplant()){
        tow[location2].setpic("lv2");
        _mygold-=plantcost;
        break;}
    }if(tow[location2].getname()=="lv2"){
        if(canbyplant()){
        tow[location2].setpic("lv3");
        _mygold-=plantcost;}
    }
    }if(tow[location2].getname()=="hong"){
        if(canbyplant()){
        tow[location2].setpic("hong2");
        _mygold-=plantcost;}
    }repaint();
}

bool first::canbyplant(){
    if(_mygold>=plantcost){
        return true;
    }else{
        return false;
    }
}

void first::drawmygold(QPainter *painter){
    painter->setPen(Qt::red);
    painter->drawText(QRect(13*50,60,3*50,100),QString("GOLD:%1").arg(_mygold));
}
