#include "bullet.h"

bullet::bullet()
{

}

bullet::bullet(QPointF startpos, QPointF endpos){
    _startpos=startpos;
    _endpos=endpos;
    _pic.load(":/tu/C:/Users/Administrator/Desktop/cs/19.jpg");
    _currentpos=QPointF((_startpos.x()+_endpos.x())/2.0,(_startpos.y()+_endpos.y())/2.0);
    _has_no=0;
}



void bullet::show(QPainter *painter){
    painter->drawImage(_currentpos.x()*50,_currentpos.y()*50,_pic);
}



