#include "mainwindow.h"
#include "ui_mainwindow.h"
int MainWindow::count=0;


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);


    if(count==0){
        ui->pushButton_2->hide();
        ui->pushButton_3->hide();
        ui->pushButton_4->hide();
        ui->pushButton_5->hide();//��Ϸ�տ�ʼʱ����һЩ�ؼ�
    }
    else{
        ui->pushButton->hide();
    }

    if(count==0){
        music=new QMediaPlayer;
        music->setMedia(QUrl("qrc:/mus/C:/Users/Administrator/Desktop/cs/tanchishe.mp3"));
        music->setVolume(50);
        music->play();
    }

    count++;
}

MainWindow::~MainWindow()
{
    delete ui;

}



void MainWindow::on_pushButton_2_clicked()
{
    first *ui1=new first;
    ui1->show();
    this->hide();
    QMediaPlayer *music=new QMediaPlayer;
    music->setMedia(QUrl("qrc:/mus/C:/Users/Administrator/Desktop/cs/ui1.wav"));
    music->setVolume(70);
    music->play();
}

void MainWindow::on_pushButton_3_clicked()
{
    second *ui2=new second;
    ui2->show();
    this->hide();
    QMediaPlayer *music=new QMediaPlayer;
    music->setMedia(QUrl("qrc:/mus/C:/Users/Administrator/Desktop/cs/ui1.wav"));
    music->setVolume(70);
    music->play();
}

void MainWindow::on_pushButton_4_clicked()
{
    third *ui3=new third;
    ui3->show();
    this->hide();
    QMediaPlayer *music=new QMediaPlayer;
    music->setMedia(QUrl("qrc:/mus/C:/Users/Administrator/Desktop/cs/ui1.wav"));
    music->setVolume(70);
    music->play();
}

void MainWindow::on_pushButton_5_clicked()
{
    QMediaPlayer *music=new QMediaPlayer;
    music->setMedia(QUrl("qrc:/mus/C:/Users/Administrator/Desktop/cs/ui1.wav"));
    music->setVolume(70);
    music->play();
}

void MainWindow::on_pushButton_clicked()
{
    QMediaPlayer *music=new QMediaPlayer;
    music->setMedia(QUrl("qrc:/mus/C:/Users/Administrator/Desktop/cs/ui1.wav"));
    music->setVolume(70);
    music->play();
}

