#include "first.h"
#include "ui_first.h"
#include"mainwindow.h"

first::first(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::first)
{
    ui->setupUi(this);
    this->init();
    ui->buttonBox->hide();
    ui->label_2->hide();
}

first::~first()
{
    delete ui;
    delete ptimer;
}

void first::on_pushButton_clicked()
{
    QMediaPlayer *music=new QMediaPlayer;
    music->setMedia(QUrl("qrc:/mus/C:/Users/Administrator/Desktop/cs/ui1.wav"));
    music->setVolume(70);
    music->play();

}


void first::on_buttonBox_accepted()
{
    MainWindow * ui0=new MainWindow;
    this->hide();
    ui0->show();
    QMediaPlayer *music=new QMediaPlayer;
    music->setMedia(QUrl("qrc:/mus/C:/Users/Administrator/Desktop/cs/ui1.wav"));
    music->setVolume(70);
    music->play();
}

void first::on_buttonBox_rejected()
{
    ui->label_2->hide();
    ui->buttonBox->hide();
    QMediaPlayer *music=new QMediaPlayer;
    music->setMedia(QUrl("qrc:/mus/C:/Users/Administrator/Desktop/cs/ui1.wav"));
    music->setVolume(70);
    music->play();
}

void first::init(){
    this->ui->lcdNumber->display("00:00");
    this->ptimer=new QTimer;
    connect(this->ptimer,SIGNAL(timeout()),this,SLOT(updatedisplay()));
    this->basetime=this->basetime.currentTime();
    this->ptimer->start(1);
}

void first::updatedisplay(){
    QTime currtime=QTime::currentTime();
    int t=this->basetime.msecsTo(currtime);
    QTime showtime(0,0);
    showtime=showtime.addMSecs(t);
    this->timestr=showtime.toString("mm:ss");
    this->ui->lcdNumber->display(timestr);
}
