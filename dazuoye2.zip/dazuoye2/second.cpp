#include "second.h"
#include "ui_second.h"

second::second(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::second)
{
    ui->setupUi(this);
    this->init();
    ui->label_2->hide();
    ui->buttonBox->hide();
}

second::~second()
{
    delete ui;
    delete ptimer;
}

void second::on_pushButton_clicked()
{
    QMediaPlayer *music=new QMediaPlayer;
    music->setMedia(QUrl("qrc:/mus/C:/Users/Administrator/Desktop/cs/ui1.wav"));
    music->setVolume(70);
    music->play();
}

void second::on_buttonBox_accepted()
{
    MainWindow *ui0=new MainWindow;
    ui0->show();
    this->hide();
    QMediaPlayer *music=new QMediaPlayer;
    music->setMedia(QUrl("qrc:/mus/C:/Users/Administrator/Desktop/cs/ui1.wav"));
    music->setVolume(70);
    music->play();
}


void second::on_buttonBox_rejected()
{
    ui->buttonBox->hide();
    ui->label_2->hide();
    QMediaPlayer *music=new QMediaPlayer;
    music->setMedia(QUrl("qrc:/mus/C:/Users/Administrator/Desktop/cs/ui1.wav"));
    music->setVolume(70);
    music->play();
}

void second::init(){
    this->ui->lcdNumber->display("00:00");
    this->ptimer=new QTimer;
    connect(this->ptimer,SIGNAL(timeout()),this,SLOT(updatedisplay()));
    this->basetime=this->basetime.currentTime();
    this->ptimer->start(1);
}

void second::updatedisplay(){
    QTime currtime=QTime::currentTime();
    int t=this->basetime.msecsTo(currtime);
    QTime showtime(0,0);
    showtime=showtime.addMSecs(t);
    this->timestr=showtime.toString("mm:ss");
    this->ui->lcdNumber->display(timestr);
}
