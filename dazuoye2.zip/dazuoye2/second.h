#ifndef SECOND_H
#define SECOND_H

#include <QDialog>
#include<QMediaPlayer>
#include"mainwindow.h"
#include<QTime>
#include<QTimer>
#include<string.h>

namespace Ui {
class second;
}

class second : public QDialog
{
    Q_OBJECT

public:
    explicit second(QWidget *parent = 0);
    ~second();
    void init();

private slots:
    void updatedisplay();
    void on_pushButton_clicked();

    void on_buttonBox_accepted();

    void on_buttonBox_rejected();

private:
    Ui::second *ui;
    QTimer *ptimer;
    QTime basetime;
    QString timestr;
};

#endif // SECOND_H
