#ifndef ICON_H
#define ICON_H


class icon
{
public:
    icon();
};

#endif // ICON_H
