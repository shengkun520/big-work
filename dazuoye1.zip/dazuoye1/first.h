#ifndef FIRST_H
#define FIRST_H

#include <QDialog>
#include"mainwindow.h"
#include<QTime>
#include<QTimer>
#include<string.h>


namespace Ui {
class first;
}

class first : public QDialog
{
    Q_OBJECT

public:
    explicit first(QWidget *parent = 0);
    ~first();
    void init();

private slots:
    void updatedisplay();
    void on_pushButton_clicked();


    void on_buttonBox_accepted();

    void on_buttonBox_rejected();

private:
    Ui::first *ui;
    QTimer *ptimer;
    QTime basetime;
    QString timestr;
};

#endif // FIRST_H
