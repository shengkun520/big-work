#include "first.h"
#include "ui_first.h"

first::first(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::first)
{
    ui->setupUi(this);
}

first::~first()
{
    delete ui;
}

void first::on_pushButton_clicked()
{
    MainWindow *ui0=new MainWindow;
    this->hide();
    ui0->show();
}
