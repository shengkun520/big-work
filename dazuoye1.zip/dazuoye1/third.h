#ifndef THIRD_H
#define THIRD_H

#include <QDialog>
#include<QMediaPlayer>
#include"mainwindow.h"
#include<QTime>
#include<QTimer>
#include<string.h>

namespace Ui {
class third;
}

class third : public QDialog
{
    Q_OBJECT

public:
    explicit third(QWidget *parent = 0);
    ~third();
    void init();

private slots:
    void updatedisplay();
    void on_pushButton_clicked();

    void on_buttonBox_accepted();

    void on_buttonBox_rejected();

private:
    Ui::third *ui;
    QTimer *ptimer;
    QTime basetime;
    QString timestr;
};

#endif // THIRD_H
